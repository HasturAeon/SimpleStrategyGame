#ifndef POINT_H
#define POINT_H


class Point
{
    public:
        Point();
        int x;
        int y;
        virtual ~Point();

    protected:

    private:
};

#endif // POINT_H
