#include "Point.h"

Point::Point()
{
    //ctor
}

Point::~Point()
{
    //dtor
}
